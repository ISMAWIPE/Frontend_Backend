import Empleado from "../models/empleado.models.js";
import mongoose from "mongoose";
import express from "express";

export const getAllEmpleados = async (req, res) => {
  console.log("Obtiene todos los empleados");
  try {
    const empleados = await Empleado.find({}, { __v: 0 });
    if (empleados.length === 0) {
      return res.status(404).json({
        msg: "No se encontraron empleados",
      });
    }
    return res.status(200).json({
      empleados,
    });
  } catch (error) {
    res.status(500).json({
      msg: "Error al obtener los empleados",
    });
  }
};

export const getEmpleadoById = async (req, res) => {
  console.log("Empleado por id");
  const id = req.params.id;
  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({
        msg: "Id no valido",
      });
    }

    const empleado = await Empleado.findById(id);
    if (!empleado) {
      return res.status(404).json({
        msg: "Empleado no encontrado",
      });
    }

    return res.status(200).json({
      empleado,
    });
  } catch (error) {
    res.status(500).json({
      msg: "Error al obtener el empleado",
    });
  }
};

export const getEmpleadoByNombre = async (req, res) => {
  const { nombre } = req.params;

  try {
    // Verifica que el parámetro sea válido
    if (!nombre || typeof nombre !== "string") {
      return res.status(400).json({ msg: "Nombre no válido" });
    }

    // Busca el documento con el nombre especificado
    const empleado = await Empleado.findOne({ nombre });

    if (!empleado) {
      return res.status(404).json({ msg: "Empleado no encontrado" });
    }

    // Retorna el documento encontrado
    return res.status(200).json({ empleado });
  } catch (error) {
    console.error("Error en getEmpleadoByNombre:", error);
    return res.status(500).json({ msg: "Error al obtener el empleado" });
  }
};

export const postEmpleado = async (req, res) => {
  console.log("Post empleado");
  const body = req.body;
  const empleado = new Empleado(body);
  try {
    const validationError = empleado.validateSync();
    if (validationError) {
      const errorMessages = Object.values(validationError.errors).map(
        (error) => error.message
      );
      return res.status(400).json({
        errors: errorMessages,
      });
    }

    await empleado.save();
    return res.status(201).json({
      msg: "Empleado guardado correctamente",
      empleado,
    });
  } catch (error) {
    return res.status(500).json({
      msg: "Error al guardar el empleado",
    });
  }
};

export const putEmpleado = async (req, res) => {
  console.log("Put empleado");
  const id = req.params.id;
  const body = req.body;
  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({
        msg: "Id no valido",
      });
    }

    const empleado = await Empleado.findByIdAndUpdate(id, body, {
      new: true,
      runValidators: true,
    });
    if (!empleado) {
      return res.status(404).json({
        msg: "Empleado no encontrado o actrualizado",
      });
    }

    return res.status(200).json({
      msg: "Empleado actualizado correctamente",
      empleado,
    });
  } catch (error) {
    return res.status(500).json({
      msg: "Error al actualizar el empleado",
    });
  }
};

export const deleteEmpleado = async (req, res) => {
  console.log("Delete empleado");
  const id = req.params.id;
  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({
        msg: "Id no valido",
      });
    }

    const empleado = await Empleado.findByIdAndDelete(id);
    if (!empleado) {
      return res.status(404).json({
        msg: "Empleado no encontrado o eliminado",
      });
    }

    return res.status(200).json({
      msg: "Empleado eliminado correctamente",
      empleado,
    });
  } catch (error) {
    return res.status(500).json({
      msg: "Error al eliminar el empleado",
    });
  }
};

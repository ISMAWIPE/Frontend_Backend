import mongoose from "mongoose";

const empleadoSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
  },
  apellido: {
    type: String,
    required: true,
  },
  roll: {
    type: String,
    required: true,
  },
  edad: {
    type: Number,
    required: false,
  },
  email: {
    type: String,
    required: false,
  },
});

const Empleado = mongoose.model("Empleado", empleadoSchema);

export default Empleado;

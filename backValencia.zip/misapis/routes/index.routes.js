import empleado from "./empleado.routes.js";
import { Router } from "express";

const indexRoutes = Router();

indexRoutes.use("/empleados", empleado);

export default indexRoutes;

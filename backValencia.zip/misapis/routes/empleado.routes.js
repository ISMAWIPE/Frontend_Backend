import { Router } from "express";
import {
  getAllEmpleados,
  getEmpleadoById,
  postEmpleado,
  putEmpleado,
  deleteEmpleado,
  getEmpleadoByNombre, // Importa esta función
} from "../controllers/empleado.controller.js";

const empleado = Router();

empleado.get("/", getAllEmpleados);

empleado.get("/:id", getEmpleadoById);

empleado.get("/nombre/:nombre", getEmpleadoByNombre); // Corrección: Usar "Empleado" en lugar de "router"

empleado.put("/:id", putEmpleado);

empleado.post("/", postEmpleado);

empleado.delete("/:id", deleteEmpleado);

export default empleado;
